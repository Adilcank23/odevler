﻿
using System.Threading.Tasks.Sources;

Console.WriteLine("tarihi gg.aa.yyyy şeklinde giriniz ");
string tarih = Console.ReadLine();
string ay = tarih.Substring(3,2);
int month = int.Parse(ay);
string[] aylar = { "ocak", "şubat", "Mart", "nisan", "mayıs", "haziran", "temmuz", "ağustos", "eylül", "ekim", "kasım", "aralık" };
if (month < 1 && month > 12)
    Console.WriteLine("böyle bir ay yok");
else
{
    Console.WriteLine(aylar[month - 1]);
}
