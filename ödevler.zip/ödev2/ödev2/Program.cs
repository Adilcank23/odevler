﻿Boolean dogru = false;
int x = 20, y = 13, z = 42;
if (23 == 55 && 76 > 45 && 5 < 12)
{
    dogru = true; 
    Console.WriteLine(dogru);
    dogru = false;
}
else Console.WriteLine(dogru);


if (23 >= 23 && 45 != 18)
{
    dogru = true;
    Console.WriteLine(dogru);
    dogru = false;
}

else Console.WriteLine(dogru);

if(x > y && z == y && z < x)
{
    dogru = true;
    Console.WriteLine(dogru);
    dogru = false;
}

else Console.WriteLine(dogru);

if(z > x && y < x)
{
    dogru = true;
    Console.WriteLine(dogru);
    dogru = false;
}

else Console.WriteLine(dogru);

if(x != z || y <= z)
{
    dogru = true;
    Console.WriteLine(dogru);
    dogru = false;
}

else Console.WriteLine(dogru);