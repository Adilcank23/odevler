﻿Console.WriteLine("açı derecesini giriniz");
int d = int.Parse(Console.ReadLine());

if (d < 0 && d > 360)
    Console.WriteLine("doğru bir derece giriniz");
else
{
    double rad = (d * (Math.PI)) / 180;
    double grad = d * 200 / 180;
Console.WriteLine("radyan "+rad+" gradyan "+grad);
}
