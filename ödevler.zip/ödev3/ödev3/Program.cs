﻿

    int x,y;
    Console.WriteLine("ilk sayıyı girin");
x = Convert.ToInt16(Console.ReadLine());
    Console.WriteLine("ikinci sayıyı girin"); 
    y = Convert.ToInt16(Console.ReadLine());


    if (x % y == 0)
    {
        Console.WriteLine(" 2 sayı birbirine bölünüyor");
    }
    else
        Console.WriteLine("birbirine bölünmeyen 2 sayı seçtiniz");
 


