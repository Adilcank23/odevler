﻿using System;

Console.WriteLine("ax^2 deki a katsayısını girin");
int a =int.Parse(Console.ReadLine());
Console.WriteLine("bx deki b katsayısını girin");
int b = int.Parse(Console.ReadLine());
Console.WriteLine("c  katsayısını girin");
int c = int.Parse(Console.ReadLine());
double d = (Math.Pow(b,2)) - 4 * a * c;

if (d < 0)
{
    Console.WriteLine("real kök yok");

}
if(d>=0)
{
    double kok1 = (double)((-b + (Math.Sqrt(d)))   / 2 * a);
    double kok2 = (double)((-b - (Math.Sqrt(d))) / 2 * a);
    Console.WriteLine(kok1);
    Console.WriteLine(kok2);
}


