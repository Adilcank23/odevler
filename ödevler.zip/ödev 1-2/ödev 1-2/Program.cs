﻿using Microsoft.Win32.SafeHandles;

Console.WriteLine(48 / 6 / 4);
Console.WriteLine(24 / 3 * 2);
Console.WriteLine((7 + 4) * 2 - 1 + 8 / 2);
Console.WriteLine((5 - 1) * 2 - 1 + 7 ^ 2 / 2);


